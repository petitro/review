#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include "reverse.h"
#include "struct.h"
#include <semaphore.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>



//Global variables
int threadsFlag = 1; //number of thread (1 by default)
char typegFlag = 'v'; //type of search vowels or consonants
int writeFlag = 0; //0 means stdout
char *fileFlag; //file to write to
int arg; //used in getopt
int nbFiles;

//Structs
struct dehash_t *dehashList;
struct answer_t *answerList;


//Rdv variables
int t_calcSum = 0;
sem_t t_calcRdv;
pthread_mutex_t t_calcMutex;
int t_readSum = 0;
sem_t t_readRdv;
pthread_mutex_t t_readMutex;


//Time tests
clock_t start;
clock_t end;


//Variables for optget
extern char *optarg;
extern int optind, opterr, optopt;
struct pc_buffer *hashBuff;

//functions
void *thread_calc();
void *thread_read(void *param);
void *thread_search();
void showResult();


int main (int argc, char *argv[]){

    start = clock();

    //Check the arguments
    int i;
    opterr = 0; //don't show error message
    while((arg = getopt(argc, argv, ":co:t:")) != -1)
    switch (arg)
        {
            case 'c':
            typegFlag = 'c';
            break;
            case 't':
            i = atoi(optarg);
            if(i > 0){
                threadsFlag = i;
            }else{
                printf("-t needs a positive int but '%s' was given\n", optarg);
                exit(EXIT_FAILURE);
            }
            break;
            case 'o':
            if(optarg[0] == '-'){
                printf("-o needs a valid file name but '%s' was given\n", optarg);
                exit(EXIT_FAILURE);
            }
            writeFlag = 1;
            fileFlag = optarg;
            break;
            case '?':
            printf("-%c is not recognize as a valid argument\n", optopt);
            exit(EXIT_FAILURE);
            case ':':
            printf("-%c is missing an argument\n", optopt);
            exit(EXIT_FAILURE);
            //TODO what to do in the default cse?
            default:
            printf("default case\n");
            exit(EXIT_FAILURE);
        }
        if(optind == argc){
            printf("You didn't provide any input file\n");
            exit(EXIT_FAILURE);
        }

        //Get input files:
        nbFiles = argc - optind;
        char *inputFiles[nbFiles];
        
        for(i = optind; i < argc; i++){
            inputFiles[i-optind] = argv[i];
        }


        //START MAIN

        //Init semaphore and mutex
        sem_init(&t_readRdv, 0, 0);
        sem_init(&t_calcRdv, 0, 0);
        pthread_mutex_init(&t_readMutex,NULL);
        pthread_mutex_init(&t_calcMutex,NULL);


        //Init buffers and lists
        printf("creating buffer\n");
        //Size of buffer is 2 times the number of threads
        int num = 2*threadsFlag;
        
        int ok;
        hashBuff = malloc(sizeof(struct pc_buffer));
        if(hashBuff == NULL){
            printf("could not malloc hashBuff\n");
            exit(EXIT_FAILURE);
        }
        ok = buffer_init(hashBuff, num);
        if(ok != 0){
            printf("Could not init hashBuff\n");
            exit(EXIT_FAILURE);
        }

        answerList = malloc(sizeof(struct answer_t));
        if(answerList == NULL){
            printf("could not malloc answerList\n");
            exit(EXIT_FAILURE);
        }
        answerList_init(answerList, 0, typegFlag);

        dehashList = malloc(sizeof(struct dehash_t));
        if(dehashList == NULL){
            printf("could not malloc dehashList\n");
            exit(EXIT_FAILURE);
        }
	    dehash_init(dehashList);


        //Open each file given
        for(i = 0; i < nbFiles; i++){
            pthread_t t_read[nbFiles];
            int err;
            err=pthread_create(&t_read[i], NULL, &thread_read, (void *) inputFiles[i]);            
            if(err!=0){
                printf("error pthread_create: %i\n", err);
                exit(EXIT_FAILURE);
            }
        }

        //Lauch calcul threads
        for(i = 0; i < threadsFlag; i++){
            pthread_t t_calc[threadsFlag];
            int t_err;
            t_err = pthread_create(&t_calc[i],NULL, &thread_calc, NULL);
            if(t_err!=0){
                printf("error creating t_calc\n");
                exit(EXIT_FAILURE);
            }
        }
        
        //Launch search threads
        pthread_t t_search;
        int er;
        er = pthread_create(&t_search, NULL, &thread_search, NULL);
        if(er!=0){
            printf("Could not lauch search thread \n");
            exit(EXIT_FAILURE);
        }
        

        //RDV t_read
        sem_wait(&t_readRdv);
        printf("all files read\n");

        //Condition to notify calc thread that all
        //hash have been read byt by adding a dummy
        //hash with flag 1
        struct hashStruct hash;
        hash.flag = 1;
        buffer_add(hashBuff, hash);

        //RDV t_calc
        sem_wait(&t_calcRdv);
        printf("all calculation done\n");

        //Condition to notify the search thread that there are
        //no more dehashed strings by adding a dummy
        //string with flag 1
        char done[4] = "end";
        dehash_add(dehashList, done, 1);

        //Wait t_search
        int join_err = pthread_join(t_search, NULL);
        if(join_err!=0){
            printf("join error \n");
        }


        end = clock();
        double time_taken = ((double)end - start)/CLOCKS_PER_SEC;
        printf("time taken: %f\n",time_taken);

        showResult();

        //free the answer list
        node_t *last = (node_t *) malloc(sizeof(node_t));
        answerList_update(answerList, 0, last);
        free(answerList->front);
        free(answerList);
        free(dehashList);
        free(hashBuff->buffer);
        free(hashBuff);

        exit(EXIT_SUCCESS);   
}




//Read input files an fill producer buffer
void *thread_read(void *param){
    int *res;
    res = (int *) malloc(sizeof(int));
    char *filename;
    filename = (char *)param;
    FILE *file;
    printf("opening %s\n", filename);
    file = fopen(filename, "rb");
    if(file == NULL){
        *res = -1;
        pthread_exit((void*) res);
    }
    ssize_t r = 1;
    
    while(r!=0){
        struct hashStruct myHash;
        r = fread(myHash.hash, 32, 1, file);
        if(r < 0){
            *res = -2;
            pthread_exit((void *) res);
        }else if (r == 0){
            continue;
        }else{
            myHash.flag = 0;
            buffer_add(hashBuff, myHash);
        }
    }
    *res = 0;
    int isClosed = fclose(file);
    if(isClosed != 0){
        printf("Could not close file %s", filename);
        exit(EXIT_FAILURE);
    }
    printf("done reading: %s\n", filename);

    //Rendez vous
    pthread_mutex_lock(&t_readMutex);
    t_readSum++;
    if(t_readSum == nbFiles){
        sem_post(&t_readRdv);
    }
    pthread_mutex_unlock(&t_readMutex);
    pthread_exit((void *) res);
}



void *thread_calc(){
    int stop = 0;
    
    while(stop == 0){
        bool *ok = (bool *) malloc(sizeof(bool));
        uint8_t *hash;
        hash = (uint8_t *) malloc(sizeof(uint8_t)*32);

        if(hash == NULL){
            printf("Could not allocate malloc\n");
            exit(EXIT_FAILURE);
        }
        struct hashStruct myHash;
        myHash = buffer_get(hashBuff);

        if(myHash.flag == 1){
            stop = 1;
            buffer_add(hashBuff, myHash);
        }else{
             //Reverse
            char *result = (char *) malloc(sizeof(char)*16); //max size of strings
            if(result == NULL){
                printf("Could not allocate malloc\n");
                exit(EXIT_FAILURE);
            }
            *ok = reversehash(myHash.hash, result, 16); //max 16
            if(ok){
                dehash_add(dehashList, result, 0);    
            }
        }
        free(ok);
    }

    //Rendez vous
    pthread_mutex_lock(&t_calcMutex);
    t_calcSum++;
    if(t_calcSum == threadsFlag){
        sem_post(&t_calcRdv);
    }
    pthread_mutex_unlock(&t_calcMutex);
    pthread_exit((void *)0);    
}


void *thread_search(){
    printf("searching\n");
    //TEST
    int nsearch = 0;
    //TEST

    char c;
    int stop = 0;
    
    while(stop == 0){

        //TEST
        nsearch++;
        //TEST

        int count = 0;
        node_t *node;
        node = dehash_get(dehashList);

        if(node->flag == 1){
            stop = 1;
        }else{
            c = answerList->type;
                
            //Counting vowels
            char *str = node->dehash;
            size_t i;
            for(i = 0; i < strlen(str); i++){
                if(*(str+i) == 'a' || *(str+i) == 'e' || *(str+i) == 'i' ||
                *(str+i) == 'o' || *(str+i) == 'u' || *(str+i) == 'y'){
                    count += 1;
                }
            }

            //Counting consonants if flag at 'c'
            if(c == 'c'){
                count = strlen(str) - count;
            }

            pthread_mutex_lock(&answerList->mutex);
            int maxrec = answerList->maxrec;
            pthread_mutex_unlock(&answerList->mutex);

            if(maxrec < count){
                answerList_update(answerList, count, node);
            }
            else if(maxrec == count){
                answerList_add(answerList, node);
                printf("result: %s\r", node->dehash);
            }else{
                free(node);
            }
        }
    }
    printf("search done: %d\n", nsearch);
    pthread_exit((void *)0);

}


void showResult(){
    int flag = writeFlag;
    int size = answerList->size;
    int i;
    node_t *current = answerList->front;
    node_t *next;

    if(flag == 0){
        printf("Answers\n");
        for(i = 0; i < size; i++){
            next = current->next;
            printf("%s\n",current->dehash);
            current =next;
        }
    }else{
        FILE *file;
        char *filename = fileFlag;
        printf("written in %s\n", filename);
        file = fopen(filename, "w");
        if(file == NULL){
            printf("Could not open file\n");
            exit(EXIT_FAILURE);
        }
        for(i = 0; i < size; i++){
            next = current->next;
            int sizeString = strlen(current->dehash);
             fwrite(current->dehash, sizeof(uint8_t)*sizeString, 1, file);
             fwrite("\n", sizeof(char), 1, file);
            if(next != NULL){
                current = next;
            }
        }
        int closed = fclose(file);
        if(closed != 0){
            printf("could not close %s file\n", filename);
            exit(EXIT_FAILURE);
        }
    }
}


