#include <stdio.h>
#include <stdlib.h>
#include <string.h>	
#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>
#include "../src/struct.h"


//Functions
void test_buffer_init();
void test_buffer_add();
void test_buffer_get();
void test_dehash_init();
void test_dehash_add();
void test_dehash_get();
void test_answerList_init();
void test_answerList_update();
void test_answerList_add();


int main(){
	CU_initialize_registry();
	CU_pSuite suite = CU_add_suite("Struct test", 0, 0);
	CU_add_test(suite, "1", test_buffer_init);
	CU_add_test(suite, "2", test_buffer_add);
	CU_add_test(suite, "3", test_buffer_get);
	CU_add_test(suite, "4", test_dehash_add);
	CU_add_test(suite, "5", test_dehash_get);
	CU_add_test(suite, "6", test_answerList_init);
	CU_add_test(suite, "7", test_answerList_update);
	CU_add_test(suite, "8", test_answerList_add);
	CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

	printf("all tests done \n");
	return 0;
}


void test_buffer_init(){
	int n = 4;
	struct pc_buffer *buf=(struct pc_buffer *) malloc(sizeof(struct pc_buffer));
	if(buf == NULL)
	{	exit(EXIT_FAILURE);	}
	buffer_init(buf,n);
	CU_ASSERT_EQUAL(buf->n, n);
	int *x =(int *) malloc(sizeof(int));
	if(x == NULL)
	{	free(buf);
		exit(EXIT_FAILURE);	}
	int *y =(int *) malloc(sizeof(int));
	if(y == NULL)
	{	free(x);
		free(buf);
		exit(EXIT_FAILURE);	}
	sem_getvalue(&buf->empty,x);
	sem_getvalue(&buf->items,y);
	CU_ASSERT_EQUAL(*x,n);
	CU_ASSERT_EQUAL(*y,0);
	CU_ASSERT_EQUAL(buf->nItems,0);
	CU_ASSERT_EQUAL(buf->rear,0);
	CU_ASSERT_EQUAL(buf->front,0);	
	free(y);
	free(x);
	free(buf);
}

void test_buffer_add(){
	int n=4;
	struct pc_buffer *ptr = (struct pc_buffer *) malloc(sizeof(struct pc_buffer));
	if(ptr == NULL)
	{	exit(EXIT_FAILURE);	}
	buffer_init(ptr,n);
	struct hashStruct add;
	uint8_t test[32] = "fool";
	memcpy(add.hash,test, sizeof(uint8_t)*32);
	buffer_add(ptr, add);
	CU_ASSERT_STRING_EQUAL(ptr->buffer->hash,test);
	CU_ASSERT_EQUAL(ptr->nItems,1);
	CU_ASSERT_EQUAL(ptr->rear,1	);
	free(ptr);
}


void test_buffer_get(){
	int n=4;

	struct pc_buffer *ptr=(struct pc_buffer *) malloc(sizeof(struct pc_buffer));
	if(ptr == NULL)
	{	exit(EXIT_FAILURE);	}

	buffer_init(ptr,n);
	struct hashStruct psw;
	struct hashStruct add;

	uint8_t test[32] = "fool";
	memcpy(add.hash,test, sizeof(uint8_t)*32);
	buffer_add(ptr, add);
	psw = buffer_get(ptr);
	CU_ASSERT_STRING_EQUAL(psw.hash,"fool");
	CU_ASSERT_PTR_NULL(ptr->buffer);
	CU_ASSERT_EQUAL(ptr->nItems,0);
	free(ptr);
}

void test_dehash_init(){
	struct dehash_t *ptr =(struct dehash_t *)malloc(sizeof(struct dehash_t));
	if(ptr == NULL)
	{	exit(EXIT_FAILURE);	}
	dehash_init(ptr);
	CU_ASSERT_EQUAL(ptr->size,0);
	free(ptr);
}


void test_dehash_add(){
	struct dehash_t *ptr =(struct dehash_t *)malloc(sizeof(struct dehash_t));
	if(ptr == NULL)
	{	exit(EXIT_FAILURE);	}
	dehash_init(ptr);
	char *psw = (char *)malloc(sizeof(char)*16);
	if(psw == NULL)
	{	free(ptr);
		exit(EXIT_FAILURE);	}
	char *psw2 = (char *)malloc(sizeof(char)*16);
	if(psw2 == NULL)
	{	free(psw);
		free(ptr);
		exit(EXIT_FAILURE);	}
	char *psw3 = (char *)malloc(sizeof(char)*16);
	if(psw3 == NULL)
	{	free(psw2);
		free(psw);
		free(ptr);
		exit(EXIT_FAILURE);	}
	psw = "gripe";
	psw2 = "cister";
	psw3 = "forker";
	CU_ASSERT_EQUAL(ptr->size,0);
	dehash_add(ptr,psw, 0);
	CU_ASSERT_STRING_EQUAL(ptr->rear->dehash,psw);
	CU_ASSERT_STRING_EQUAL(ptr->front->dehash,psw);
	CU_ASSERT_EQUAL(ptr->size,1);
	dehash_add(ptr,psw2,0);
	CU_ASSERT_STRING_EQUAL(ptr->rear->dehash,psw2);
	CU_ASSERT_STRING_EQUAL(ptr->front->dehash,psw);
	CU_ASSERT_EQUAL(ptr->size,2);
	dehash_add(ptr,psw3,0);
	CU_ASSERT_STRING_EQUAL(ptr->rear->dehash,psw3);
	CU_ASSERT_STRING_EQUAL(ptr->front->dehash,psw);
	CU_ASSERT_EQUAL(ptr->size,3);
	free(psw3);
	free(psw2);
	free(psw);
	free(ptr);
}

void test_dehash_get(){
	struct dehash_t *ptr = (struct dehash_t *)malloc(sizeof(struct dehash_t));
	if(ptr == NULL)
	{	exit(EXIT_FAILURE);	}
	dehash_init(ptr);
	char *psw = (char *)malloc(sizeof(char)*16);
	if(psw == NULL)
	{	free(ptr);
		exit(EXIT_FAILURE);	}
	char *psw2 = (char *)malloc(sizeof(char)*16);
	if(psw2 == NULL)
	{	free(psw);
		free(ptr);
		exit(EXIT_FAILURE);	}
	char *psw3 = (char *)malloc(sizeof(char)*16);
	if(psw3 == NULL)
	{	free(psw2);
		free(psw);
		free(ptr);
		exit(EXIT_FAILURE);	}
	psw = "gripe";
	psw2 = "cister";
	psw3 = "forker";
	dehash_add(ptr,psw, 0);
	dehash_add(ptr,psw2, 0);
	dehash_add(ptr,psw3, 0);
	node_t *node;
	node = dehash_get(ptr);
	CU_ASSERT_STRING_EQUAL(node->dehash,"gripe")
	CU_ASSERT_STRING_EQUAL(ptr->front->dehash,"cister")
	CU_ASSERT_STRING_EQUAL(ptr->rear->dehash,"forker")
	CU_ASSERT_EQUAL(ptr->size,2);	
	free(node);
	free(psw2);
	free(psw);
	free(ptr);
}

void test_answerList_init(){
	struct answer_t *test_ans;
	test_ans = malloc(sizeof(struct answer_t));
        if(test_ans == NULL){
        	exit(EXIT_FAILURE);
	}
	answerList_init(test_ans,1,'c');
	CU_ASSERT_EQUAL(test_ans->size,0);
	CU_ASSERT_EQUAL(test_ans->maxrec,1);
	CU_ASSERT_STRING_EQUAL(test_ans->type,'c');
	free(test_ans);
}

void test_answerList_update(){
	struct answer_t *test_ans;
	test_ans = malloc(sizeof(struct answer_t));
        if(test_ans == NULL){
        	exit(EXIT_FAILURE);
	}
	struct node_t *node;
	node = malloc(sizeof(struct node_t));
	if(node == NULL){
        	free(test_ans);
		exit(EXIT_FAILURE);
	}
	char *psw = (char *)malloc(sizeof(char)*16);
	if(psw ==NULL){
		free(node);
		free(test_ans);
	}
	int count = 2;
	psw = "gripe";
	node->dehash = psw;
	answerList_init(test_ans,0,'v');
	answerList_update(test_ans,count,node);
	CU_ASSERT_STRING_EQUAL(test_ans->front->dehash,"gripe");
	CU_ASSERT_STRING_EQUAL(test_ans->rear->dehash,"gripe");
	CU_ASSERT_EQUAL(test_ans->size,1);
	CU_ASSERT_EQUAL(test_ans->maxrec,2);
	free(psw);
	free(node);
	free(test_ans);
}

void test_answerList_add(){
	struct answer_t *test_ans;
	test_ans = malloc(sizeof(struct answer_t));
        if(test_ans == NULL){
        	exit(EXIT_FAILURE);
	}
	struct node_t *node;
	node = malloc(sizeof(struct node_t));
	if(node == NULL){
        	free(test_ans);
		exit(EXIT_FAILURE);
	}
	struct node_t *node2;
	node2 = malloc(sizeof(struct node_t));
	if(node2 == NULL){
        	free(node);
		free(test_ans);
		exit(EXIT_FAILURE);
	}
	char *psw = (char *)malloc(sizeof(char)*16);
	if(psw == NULL)
	{	free(node2);
		free(node);
		free(test_ans);
		exit(EXIT_FAILURE);	}
	char *psw2 = (char *)malloc(sizeof(char)*16);
	if(psw2 == NULL)
	{	free(psw);
		free(node2);
		free(node);
		free(test_ans);
		exit(EXIT_FAILURE);	}
	psw = "gripe";
	psw2 = "cister";
	node->dehash = psw;
	node2->dehash = psw2;
	answerList_init(test_ans,0,'v');
	answerList_add(test_ans,node);
	CU_ASSERT_EQUAL(test_ans->size,1);
	CU_ASSERT_STRING_EQUAL(test_ans->front->dehash,"gripe");
	CU_ASSERT_STRING_EQUAL(test_ans->rear->dehash,"gripe");
	answerList_add(test_ans,node2);
	CU_ASSERT_EQUAL(test_ans->size,2);
	CU_ASSERT_STRING_EQUAL(test_ans->front->dehash,"gripe");
	CU_ASSERT_STRING_EQUAL(test_ans->rear->dehash,"cister");
	free(psw2);
	free(psw);
	free(node2);
	free(node);
	free(test_ans);

}















