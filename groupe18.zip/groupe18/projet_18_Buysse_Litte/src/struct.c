
#include "struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>
#include <string.h>



int buffer_init(struct pc_buffer *buf, int n){
    buf->buffer =  (struct hashStruct *) malloc(sizeof(struct hashStruct)*n);
    if(buf->buffer == NULL){
        return -1;
    }
    buf-> n = n;
    buf->nItems = 0;
    buf->front = buf->rear = 0;
    sem_init(&buf->empty,0, n);
    sem_init(&buf->items, 0,0);
    pthread_mutex_init(&buf->mutex,NULL);
    return 0;
}

void buffer_add(struct pc_buffer *buffer, hashStruct newHash){
    //BLOCK
    sem_wait(&buffer->empty);
    pthread_mutex_lock(&buffer->mutex);

    buffer->buffer[buffer->rear] = newHash;
    buffer->rear = (buffer->rear + 1)%buffer->n;
    buffer->nItems = buffer->nItems + 1;
    sem_post(&buffer->items);

    pthread_mutex_unlock(&buffer->mutex);
}

struct hashStruct buffer_get(struct pc_buffer*buffer){
    struct hashStruct myHash;
    //BLOCK
    sem_wait(&buffer->items);
    pthread_mutex_lock(&buffer->mutex);

    myHash = buffer->buffer[buffer->front];
    buffer->front = (buffer->front+1)%buffer->n;
    buffer->nItems = buffer->nItems - 1;

    sem_post(&buffer->empty);
    pthread_mutex_unlock(&buffer->mutex);

    return myHash;
}


void dehash_init(struct dehash_t *list){
    sem_init(&list->items, 0, 0);
    list->size = 0;
    pthread_mutex_init(&list->mutex,NULL);
}

void dehash_add(struct dehash_t *list, char *res, int flag){
    node_t *node = (node_t *)malloc(sizeof(node_t));
    if(node == NULL){
	    exit(EXIT_FAILURE);
    }
    char *copy = (char *)malloc(sizeof(char)*(strlen(res) + 1));
    strcpy(copy,res);
    node->dehash = copy;
    node->flag = flag;
    pthread_mutex_lock(&list->mutex);
    if(list->size == 0){
	    list->front = node;
	    list->rear = node;
    }else{
	    list->rear->next = node;
	    list->rear = node;
    }
    list->size = list->size + 1;
    sem_post(&list->items);
    pthread_mutex_unlock(&list->mutex);
}

struct node_t *dehash_get(struct dehash_t *list){
    node_t *node;
    sem_wait(&list->items);
    pthread_mutex_lock(&list->mutex);
    node = list->front;
    list->size -= 1;
    if(list->size > 0){
        list->front = node->next;
    } 
    pthread_mutex_unlock(&list->mutex);
    return node;
}


void answerList_init(answer_t *list, int rec, char type){
    list->size = 0;
    list->maxrec = rec;
    list->type = type;
    pthread_mutex_init(&list->mutex, NULL);
}


void answerList_update(answer_t *list, int maxrec, node_t *node){
    int i;
    node_t *current;
    node_t *next;
    node->next = NULL;
    pthread_mutex_lock(&list->mutex);
    //free all current nodes
    current = list->front;
    for(i=0; i < list->size; i++){
        next = current->next;
        free(current);
        current = next;
    }
    list->maxrec = maxrec;
    list->front = node;
    list->rear = node;
    list->size = 1;
    pthread_mutex_unlock(&list->mutex);
}


void answerList_add(answer_t *list, node_t *node){
    pthread_mutex_lock(&list->mutex);
    if(list->size == 0){
        list->front = node;
        list->rear = node;
    }else{
        list->rear->next = node;
        list->rear = node;
    }
    list->size = list->size + 1;
    pthread_mutex_unlock(&list->mutex);
}
