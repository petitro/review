#ifndef _STRUCT_H
#define _STRUCT_H

#include <semaphore.h>
#include <stdint.h>
#include <pthread.h>


typedef struct answer_t{
    struct node_t *front;
    struct node_t *rear;
    int size;
    int maxrec;
    char type;
    pthread_mutex_t mutex;
}answer_t;

//Producer/Consumer buffer like in the course
typedef struct pc_buffer{
    struct hashStruct *buffer;
    int n;
    int nItems;
    int front;
    int rear;
    pthread_mutex_t mutex;
    sem_t empty; //empty places
    sem_t items; //number of items in it
}pc_buffer;

typedef struct hashStruct {
    int flag;
    uint8_t hash[32];
}hashStruct;


//linkedlist of dehashed passwords
typedef struct dehash_t{
struct node_t *front;
struct node_t *rear;
int size;
sem_t items;
pthread_mutex_t mutex;
} ansDehash;

//dehashed password
typedef struct node_t{
char *dehash;
int flag;
struct node_t *next;
} node_t;




//Functions


//pc_buffer functions

/* buffer_init
 * Initialize a pc_buffer struct with a size of n hashStruct
 *
 * @buffer: the buffer to initilize
 * @n: size of the buffer
 * @return: 0 if ok or -1 if he couldn't malloc
 */
int buffer_init(struct pc_buffer *buffer, int n);

/* buffer_add
 * Add a hashStruct to the rear of the buffer of hash
 *
 * @buffer: the buffer to add to
 * @newHash: the hashStruct to be added
 * @return: void
 */
void buffer_add(struct pc_buffer *buffer, struct hashStruct newHash);

/* buffer_get
 * Remove the front hashStruct of the buffer of hash
 *
 * @buffer: the buffer to remove from
 * @return: the removed hashStruct
 */
struct hashStruct buffer_get(struct pc_buffer *buffer);


//dehash_t functions

/* dehash_init
 * Initialize a dehash_t linked list of d_node with no elements
 *
 * @list: the dehash_t linked list
 * @return: void
 */
void dehash_init(struct dehash_t *list);

/* dehash_add
 * Initialize a d_node with the value res and
 * add it at the rear of the dehash_t linked list
 *
 * @list: the dehash_t linked list
 * @res: the dehashed string to be stocked
 * @flag: flag used to notify if it is the last element
 * @return: void
 */
void dehash_add(struct dehash_t *list, char *res, int flag);

/* dehash_get
 * Remove the front d_node of the given dehash_t linked list
 *
 * @list: the dehash_t linked list
 * @return: the d_node removed
 */
struct node_t *dehash_get(struct dehash_t *list);


//answer_t functions


/* answerList_init
 * Initialize the given answer_t list
 *
 * @list: the answer_t linked list
 * @rec: the maximum recorded occurences
 * @type: 'c' or 'v' to know if we searching for vowels or consonants
 * @return: void
 */
void answerList_init(answer_t *list, int rec, char type);

/* answerList_update
 * Free the current list and change rec to the new maxrec and
 * add the first node to it
 *
 * @list: the answer_t linked list
 * @maxrec: the new maximum recorded occurences
 * @node: the first to add that has a maxrec occurence
 * @return: void
 */
void answerList_update(answer_t *list, int maxrec, node_t *node);

/* answerList_add
 * Add a node at the end of the answer_t list
 *
 * @list: the answer_t linked list
 * @node: the valid node to add
 * @return: void
 */
void answerList_add(answer_t *list, node_t *node);

#endif
