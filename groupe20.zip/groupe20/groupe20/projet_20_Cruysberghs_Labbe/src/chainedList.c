#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "chainedList.h"

/**
 * chainedList.c is a file wich contains all the functions concerning to the
 * chained list like push pop and clear
 *
 */

 node_t* push(char* pswrd, node_t* old){
   node_t* new = malloc(sizeof(node_t));
   if(new==NULL){
     fprintf(stderr, "Error while allocating memory for candidate in the chained list (push)\n");
     exit(EXIT_FAILURE);
   }
   new->next = old;
   new->word = pswrd;
   return new;
 }

 node_t* init(node_t* list){
   char *initchar = malloc(sizeof(char)+1);
   if(initchar==NULL){
     fprintf(stderr, "Error while allocating memory for an unreal candidate in the chained list (init)\n");
     exit(EXIT_FAILURE);
   }
   strcpy(initchar,"0P");

   list = push(initchar,list);
   return list;
 }

 node_t* pop(node_t* top){
  if((top->word)[0] != 0){
    node_t* new = top->next;
    free(top->word);
    free(top);
    return new;
  }
  return top;
}


 char* get(node_t* top){
   return top->word;
 }

 int get0(node_t* top){
   char *end=malloc(sizeof(char)*3);
   if(end==NULL){
     fprintf(stderr, "Error while allocating memory for get0\n");
     exit(EXIT_FAILURE);
   }
   strcpy(end,"0P");
   return strcmp(top->word,end);
   // printf(top->word);
   //   return 'a' ;//top->word[0];
 }

 node_t* clear(node_t* top){
  node_t* new = top;
  while(new->word[0] != 0){
    printf("%s\n", get(new));
    new = pop(new);
  }
  return new;
}
