#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>

#include "chainedList.h"
#include "chainedList.c"
#include "reverse.h"
#include "reverse.c"



int nThreads = 2;
int arrayMultiply = 3;      // Coeff to multiply to set the length of hashArray and passwordArray
uint8_t **hashArray;
char **passwordArray;       // Array of candidates [strings]



// function used in producer.
// this function changes an 8 bit binary digit to a char corresponding to its hexadecimal value
// it simply does a 4 bit traduction so it also take a 'l' or 'r' character to precise which side is chosen
uint8_t bi2Hex(uint8_t binary, char side){
  //printf("%c\n",side);
  uint8_t hex;
  if(side=='r'){
     binary = binary & 0b00001111;  // takes the first 4 bits (right side)
  }
  else{
    binary = binary >> 4;           // takes the last 4 bits (left side)
  }
  if((int) binary <= 9){      // if it's a value between 0-9 it just writes it in the array as a char
    hex='0' + (int)binary;
  }
  else{                             // if not it writes A-F when bin varies from 10-16
    hex=(int)binary + 'A' - 10;
  }
  //printf("%c\n",hex);
  return hex;                       // returns the char '1'-'9' or 'A'-'F'
}


/* function used in consumer
   verifies if an array has values other than NULL. (so if an array has only NULLs it will return 0)
   It also changes a pointer to one of the hashes to be used in the consumer function    */
int isEmpty(uint8_t* hash){

  // sem_wait(&hashMutexFull);                       // Sem Hash consumer start
  // pthread_mutex_lock(&lockHash);
  // char* hash2 = (char *) hash;
  for (size_t i = 0; i < arrayMultiply*nThreads; i++) {
    if(hashArray[i] != NULL){
      hash = hashArray[i];
      hashArray[i] = NULL;

      // pthread_mutex_unlock(&lockHash);
      // sem_post(&hashMutexEmpty);                  //Sem Hash consumer end

      return 1;
      }
  }

  // pthread_mutex_unlock(&lockHash);                 // Sem Hash consumer end bis
  // sem_post(&hashMutexEmpty);

  return 0;
}


// reads a single binary file, translates the hashes of 32 bytes to a string version of hexadecimal(64 chars)
// and finally writes those hexatext arrays into an "open spot" in hashArray (where there is a NULL).
void *producer(char *filename){

  //printf("P1\n");

  //producerAmmount++;


  uint8_t byte;


  FILE *file = fopen(filename, "r");               // Only opens file with read permition
  if(file==NULL){
    fprintf(stderr, "Error, file %s is empty\n", filename);
    exit(EXIT_FAILURE);
  }

  if(file == NULL){
    fprintf(stderr, "Error, file %s is empty\n", filename);

    exit(EXIT_FAILURE);

  }
  else{

    //while (file != NULL)
    for(int f=0; f<5;f++){
      uint8_t *hexa = (uint8_t*) malloc(sizeof(uint8_t)*64+1);        // Malloc for the hash and is freed after being reversed
      if (hexa == NULL) {
        //printf("P5\n");
        fprintf(stderr, "Error while allocating memorry for the producer");
        exit(EXIT_FAILURE);
      }
      byte = fgetc(file);
      if(byte==EOF){
       fprintf(stderr, "Error, file %s is empty\n", filename);
       exit(EXIT_FAILURE);
      }

      for (size_t i = 0; i < 64 && file != NULL; i++){  // writes the 64 characters
        //printf("P8\n");
        if(!(i%2)){
          hexa[i] = bi2Hex(byte,'r');
        }
        else{
          hexa[i] = bi2Hex(byte,'l');
          byte = fgetc(file);            // initialised to the next byte
        }
      }
      //only one thread can go here to fill the array or it could get stuck
      // (the program knows if there is an open spot with muttex)

      //sem_wait(&hashMutexEmpty);                   // Sem Hash producer start
      //pthread_mutex_lock(&lockHash);

      for (size_t i = 0; i < arrayMultiply*nThreads; i++) {
        if(hashArray[i] == NULL){  // finds the open spot to fill it in
          hashArray[i]= hexa;
          i = arrayMultiply*nThreads;
        }
      }


      //pthread_mutex_unlock(&lockHash);             // Sem Hash producer end
      //sem_post(&hashMutexFull);
    }
    fclose(file);
    //producerAmmount--;     // Lets the consumer know its this producer is done
    fprintf(stdout,"%s\n%s\n%s\n%s\n%s\n", hashArray[0], hashArray[1],hashArray[2],hashArray[3],hashArray[4]);
  }
  return 0;
}




// Reverses the hashes [strings] (from the hashArray) to passwords [strings]
// And writes the candidates in the passwordArray.
void *consumer(){
  uint8_t *hash = NULL;
  while( isEmpty(hash)){          // (*) ?

    // malloc for the password. freed when it is writen in the file or dismissed
    char *password = (char *) malloc(sizeof(char)*16+1);
    if (password == NULL) {
      fprintf(stderr, "Error while allocating memorry for the consumer");
      exit(EXIT_FAILURE);
    }
    // hash = (char* ) hash;
    if(reversehash(hash,password,16)){                   // (*) ?

      // sem_wait(&passwordMutexEmpty);                   // Sem password producer start
      // pthread_mutex_lock(&lockPassword);

      // finds an open spot to write the new candidate
      for (size_t i = 0; i < arrayMultiply*nThreads; i++) {
        if(passwordArray[i] == NULL){
          passwordArray[i] = password;
          i = arrayMultiply*nThreads;
        }
      }

      // pthread_mutex_unlock(&lockPassword);             // Sem password producer end
      // sem_post(&passwordMutexFull);

    }
    free(hash);  // the used hash isnt needed anymore
    hash = NULL;
  }
  return NULL;
}



int main (int argc, char *argv[]){
  hashArray=(uint8_t **) calloc(arrayMultiply*nThreads,32);
  char *filename= "../../test-input/02_6c_5.bin";
    // char *filename= "../../test-input/01_4c_1k.bin";
	producer(filename);
  consumer();
	return 0;
}
