#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

#include "chainedList.h"
#include "reverse.h"



//---------------------------------------------------GLOBAL_VARIABLES-------------------------------------------------//

// The path followed by the data is as such:
// File --> hashArray{list of strings} --> passwordArray{list of strings} --> passwords{chainedList} --> outputFile

uint8_t **hashArray;        // Array of hashed passwords [strings]

char **passwordArray;       // Array of candidates [strings]

node_t* passwords;    // Chained list (top of stack)

int nThreads = 1;           // Number of consumer threads (set to one if not specified)
int arrayMultiply = 3;      // Coeff to multiply to set the length of hashArray and passwordArray
int vowel= 1;           // variable automaticaly set to vowel based on the instructions.


// Thread variables with the layout inspired by:
// https://sites.uclouvain.be/SystInfo/notes/Theorie/html/Threads/coordination.html
pthread_mutex_t lockHash;
sem_t hashMutexEmpty;
sem_t hashMutexFull;
pthread_mutex_t lockPassword;
sem_t passwordMutexEmpty;
sem_t passwordMutexFull;

sem_t producerMutex;
sem_t consumerMutex;

pthread_mutex_t lockLoop;


//----------------------------------------------------------PRODUCER--------------------------------------------------//


// Reads a single binary file and writes those uint8_t arrays into an "open spot" in hashArray (where there is a NULL).
void *producer(void *filenamevoid){
  // Initialization
  char * filename = (char *) filenamevoid;
  //uint8_t byte;                // Contains a binary byte read from the file
  void *hexa;               // Contains a hexadecimal string from the traduction
  FILE *file;
  size_t i;                    // Variable for the loops

  file = fopen(filename, "r");
  //int n = open(filename", O_RDONLY)               // Only opens the file with read permition
  if(file == NULL){
    fprintf(stderr, "Error, file %s is empty\n", filename);
    exit(EXIT_FAILURE);
  }
  else{

    hexa = (void*) malloc(sizeof(uint8_t)*32);        // Malloc for the hash and is freed after being reversed
    if (hexa == NULL) {                                    // Check Malloc
      fprintf(stderr, "Error while allocating memorry for the producer\n");
      exit(EXIT_FAILURE);
    }

    while (fread(hexa, 32, 1, file)==1){

      // Only one thread can pass here to fill the array or data could be lost.
      // (the program knows if there is an open spot with semaphor)
      sem_wait(&hashMutexEmpty);                   // Sem Hash producer start
      pthread_mutex_lock(&lockHash);

      for (i = 0; i < arrayMultiply*nThreads; i++) {
        if(hashArray[i] == NULL){                  // Finds the open spot to fill it in.
          hashArray[i] = (uint8_t*) hexa;
          i = arrayMultiply*nThreads;              // Leave loop after a succesfull write.
        }
      }

      pthread_mutex_unlock(&lockHash);             // Sem Hash producer end
      sem_post(&hashMutexFull);

      hexa = (void*) malloc(sizeof(uint8_t)*32);        // Malloc for the hash and is freed after being reversed
      if (hexa == NULL) {                                    // Check Malloc
        fprintf(stderr, "Error while allocating memorry for the producer\n");
        exit(EXIT_FAILURE);
      }
    }

    free(hexa);
    fclose(file);

  }
  sem_wait(&producerMutex);
  pthread_exit(NULL);
}
//----------------------------------------------------CONSUMER---------------------------------------------------//


int canConsumerLoop(){
  int i, j;
  sem_getvalue(&producerMutex, &i);
  sem_getvalue(&hashMutexFull, &j);
  return (i || j);
}

// Reverses the hashes [strings] (from the hashArray) to passwords [strings]
// And writes the candidates in the passwordArray.
void *consumer(){
  // Initialization
  uint8_t *hash = NULL;     // Contains a hexadecimal [string] from hashArray
  size_t i;                 // Variable for the loops
  char *password;           // Contains a password [string] after being reversed

  while(canConsumerLoop()){//producerAmmount || hashesReady){

    /* Lock loop is a system to prevent the last threads from being stuck if there
    is only one hash left. The rest of threads will
 char*  automatically leave the loop
    (when there is nothing left) if they got up to here.
    */
    pthread_mutex_lock(&lockLoop);

    if(canConsumerLoop()){
      sem_wait(&hashMutexFull);              // Sem Hash consumer start
      pthread_mutex_lock(&lockHash);         // Lock the hash to prevent producer changements

      for (i = 0; i < arrayMultiply*nThreads; i++) {
        if(hashArray[i] != NULL){           // Lemoves a hash from the hashArray
          hash = hashArray[i];
          hashArray[i] = NULL;
          i = arrayMultiply*nThreads;       // Leaves loop
        }
      }
      pthread_mutex_unlock(&lockHash);                 // Sem Hash consumer end
      sem_post(&hashMutexEmpty);

      pthread_mutex_unlock(&lockLoop);
    }
    else{
      pthread_mutex_unlock(&lockLoop);
      break;                    // Leaves the while for when nothing is left to do.
    }

    // malloc for the password. freed when it is writen in the file or dismissed.
    password = (char*) malloc(sizeof(char)*16+1);
    if (password == NULL) {                            // Error check
      fprintf(stderr, "Error while allocating memorry for the consumer\n");
      exit(EXIT_FAILURE);
    }

    // if a password is found, it is writen into an open passwordArray spot
    if(reversehash(hash,password,16)){

      printf("%s\n",password); // to print all the password because we didn't go throught the save functions :/


      sem_wait(&passwordMutexEmpty);                   // Sem password producer start
      pthread_mutex_lock(&lockPassword);

      // finds an open spot to write the new candidate
      for (i = 0; i < arrayMultiply*nThreads; i++) {
        if(passwordArray[i] == NULL){
          passwordArray[i] = password;
          i = arrayMultiply*nThreads;       // Leaves the loop
        }
      }

      pthread_mutex_unlock(&lockPassword);             // Sem password producer end
      sem_post(&passwordMutexFull);

    }
    hash = NULL;
  }
  free(hash);                             // The used hash isnt needed anymore

  sem_wait(&consumerMutex);
  pthread_exit(NULL);
}




//----------------------------------------------------SORTER------------------------------------------------//


int canSorterLoop(){
  int i, j;
  sem_getvalue(&consumerMutex, &i);
  sem_getvalue(&passwordMutexFull, &j);
  return (i || j);
}
/* Function used in sorter
 Compares the ammount of vowels/consonants between each strings annd if 'candidtate' has more of either one,
 Tt returns a positive int. if the have an equal number then it returns 0, and negatif for the last case.
*/
int isCandidateGood(char* oldCandidate, char* candidate){
  //Initialization
  size_t i;                                 // variable for the loops
  int oldScore = 0, newScore = 0;
  char old;//, new;                            // Allows to have a smaller if condition
  // The 2 passwords are not in the same loops since their length can be different
  for (i = 0; i < 16 && !candidate[i]; i++) {
    old = oldCandidate[i];
    if( old == 'a' || old == 'e' || old == 'i' || old == 'o' || old == 'u' || old == 'y'){
      if(vowel){oldScore++;}
    }
    else{
      if(!vowel){oldScore++;}
    }
  }
  // printf("isCandidateGood3\n");
  // for (i = 0; i < 16 && !oldCandidate[i]; i++) {
  //   new = candidate[i];
  //   if( new == 'a' || new == 'e' || new == 'i' || new == 'o' || new == 'u' || new == 'y'){
  //     if(vowel){newScore++;}
  //   }
  //   else{
  //     if(!vowel){newScore++;}
  //   }
  // }
  // printf("isCandidateGood4\n");
  return newScore-oldScore;
}


// Reads the passwordArray and sorts the correct passwords in the chainnedArray.
void *sorter(){
  // Initialization
  char* newPassword;
  char* firstCandidate = NULL;
  size_t i;
  int result;
  int pmf;

  // Stops when there are no passwords in the procces of being created or already created
  while(canSorterLoop()){//consumerAmmount || passwordsReady) {

    sem_getvalue(&passwordMutexFull,&pmf);
    sem_wait(&passwordMutexFull);                       // Sem Password consumer start
    pthread_mutex_lock(&lockPassword);
    for (i = 0; i < arrayMultiply*nThreads; i++) {
      if(passwordArray[i]!=NULL){
        newPassword = passwordArray[i];
        passwordArray[i] = NULL;
        i = arrayMultiply*nThreads;
      }
    }

    pthread_mutex_unlock(&lockPassword);
    sem_post(&passwordMutexEmpty);                  // Sem Password consumer end
    firstCandidate = get(passwords);
    result = isCandidateGood(firstCandidate, newPassword);
    // No need to protect the password array functions since only 1 sorter thread exists
    if(result < 0){
      free(passwordArray[i]);    // Password isnt better than the other so it's freed
      passwordArray[i] = NULL;
    }
    if(!result){                 // Password is as good as the others so its added to the stack
      passwords = push(passwordArray[i],passwords);

    }
    else{
      passwords = clear(passwords);          // password is better than the others so all the others are freed
      passwords = push(passwordArray[i],passwords);
    }
  }

  pthread_exit(NULL);
}

/*
 * @pre  filename, the output to write (a file or the stdout)
 * @post writes the list of candidate in the file.
 *       return
 *       EXIT_FAILURE if something failed
 */
// void save(char *filename){
//   FILE *file;
//   char *buf;
//   int i;
//   if(filename!=NULL){
//     file = fopen(filename,"w");
//     if(file==NULL){
//         fprintf(stderr, "Error while opening the file\n");
//         exit(EXIT_FAILURE);
//     }
//     while(get0(passwords)!='0'){
//     //while(){
//       // for(int i=0; i<300; i++){
//       buf = malloc(sizeof(char)*17);
//       if(buf==NULL){
//         fprintf(stderr, "Error while writing the file (malloc)\n");
//         exit(EXIT_FAILURE);
//       }
//
//       buf = get(passwords);
//         i = fwrite(buf,sizeof(char),(16+1),file);
//         if(i != (16+1)){
//           fprintf(stderr, "Error while writing the file\n");
//           exit(EXIT_FAILURE);
//         }
//
//       passwords = pop(passwords);
//
//     }
//     i=fclose(file);
//     if(i!=0){
//       fprintf(stderr, "Error while closing the file\n");
//       exit(EXIT_FAILURE);
//     }
//   }
//   else{
//     while(get0(passwords)){
//       buf = malloc(sizeof(char)*17);
//       if(buf==NULL){  printf("Main6b\n");
//         fprintf(stderr, "Error while writing the file (malloc)\n");
//         exit(EXIT_FAILURE);
//       }
//       buf = get(passwords);
//       fprintf(stdout,"%s\n",buf);
//       free(buf);
//       passwords = pop(passwords);
//     }
//   }
// }


//----------------------------------------------------MAIN---------------------------------------------------//
int main (int argc, char *argv[]){

  // Initialization
	//char *fileOut;
  char **filesIn;
	int posT = 0;        // Position of the t character and
	int posC = 0;
  int posO = 0;
  int i;    // Variable for the loops
  int j= 0;  // For loop on filesIasswords = init(passwords);n
  int nbrFilesIn;
  int value;
  pthread_t *threadsP;
  pthread_t *threadsC;
  pthread_t threadS;

  passwords = init(passwords);

  // To treat the diffrent arguments in an non-sepcify order
  for(i=1; i <argc; i++){
		if(!strcmp(argv[i],"-t")){
			nThreads = atoi(argv[i+1]);
			posT=i;
		}
		if(!strcmp(argv[i],"-c")){
			posC=i;
      vowel=0;                // Sort in function of consonant instead of vowel
		}
    if(!strcmp(argv[i],"-o"))
      posO=i;
			//fileOut = argv[i+1];
	}

  hashArray=(uint8_t **) calloc(arrayMultiply*nThreads,32); // Calloc instead of malloc because the producer needs
  // if(passwordArray==NULL){                                         // to know if a spot is empty (=NULL) to work
  //   fprintf(stderr, "Error: while allocating and freeing dynamic memory (hashArray)\n");
  //   exit(EXIT_FAILURE);
  // }

  passwordArray=(char **) calloc(arrayMultiply*nThreads,16);
  // if(passwordArray==NULL){
  //   fprintf(stderr, "Error: while allocating and freeing dynamic memory (passwordArray)\n");
  //   exit(EXIT_FAILURE);
  // }

  // Complete filesIn by the the files in arguments
	nbrFilesIn=argc-2*(posT>0)-(posC>0)-2*(posO>0)-1;
  if(nbrFilesIn<1){
    fprintf(stderr, "Error: there is no intput file to work on\n");
    exit(EXIT_FAILURE);
  }

	filesIn= (char **) malloc(sizeof(char*)*nbrFilesIn);
  if(filesIn==NULL){
    fprintf(stderr, "Error while allocating memory for filesIn\n");
    exit(EXIT_FAILURE);
  }

	for(i=0;i<argc;i++){
		if(i!=posC && i!= posT && i!= (posT+1) && i!=posO && i!=(posO+1)){
			filesIn[j]=argv[i];
      j++;
		}
	}


  // Semaphore initialization for the double producer consumer
  if(sem_init(&hashMutexEmpty, 0, (arrayMultiply*nThreads)-0)!=0){
    fprintf(stderr, "Error while initializing the semaphore hashMutexEmpty\n");
    exit(EXIT_FAILURE);
  }
  if(sem_init(&hashMutexFull, 0, 0)){
    fprintf(stderr, "Error while initializing the semaphore hashMutexFull\n");
    exit(EXIT_FAILURE);
  }
  if(sem_init(&passwordMutexEmpty, 0, (arrayMultiply*nThreads)-0)!=0){
    fprintf(stderr, "Error while initializing the semaphore passwordMutexEmpty\n");
    exit(EXIT_FAILURE);
  };
  if(sem_init(&passwordMutexFull, 0, 0)!=0){
    fprintf(stderr, "Error while initializing the semaphore passwordMutexFull\n");
    exit(EXIT_FAILURE);
  }
  if(pthread_mutex_init(&lockHash, NULL)!=0){
    fprintf(stderr, "Error while initializing the mutex lockHash\n");
    exit(EXIT_FAILURE);
  }
  if(pthread_mutex_init(&lockPassword, NULL)!=0){
    fprintf(stderr, "Error while initializing the mutex unlockHash\n");
    exit(EXIT_FAILURE);
  }

  if(sem_init(&producerMutex, 0, nbrFilesIn)!=0){
    fprintf(stderr, "Error while initializing the semaphore hashMutexEmpty\n");
    exit(EXIT_FAILURE);
  }
  if(sem_init(&consumerMutex, 0, nThreads)!=0){
    fprintf(stderr, "Error while initializing the semaphore hashMutexEmpty\n");
    exit(EXIT_FAILURE);
  }



  // Allocate and free dynamic marrayMultiply*nThreadsemory
  threadsP= (pthread_t *) malloc(sizeof(pthread_t)*nbrFilesIn);
  if(threadsP==NULL){
    fprintf(stderr, "Error while allocating memory for threadsP\n");
    exit(EXIT_FAILURE);
  }
  threadsC= (pthread_t *) malloc(sizeof(pthread_t)*nThreads);
  if(threadsC==NULL){
    fprintf(stderr, "Error while allocating memory for threadsC\n");
    exit(EXIT_FAILURE);
  }



  //thread_t threadsP[nbrFilesIn]; // One producer thread for every input file.
  // Create the threads
	for(i=0; i<nbrFilesIn; i++){                   // Not ready for files's type
	  value=pthread_create(&threadsP[i],NULL,&producer,(void *) filesIn[i]);
    if(value){
      fprintf(stderr, "Error during the producer threads launch. Error number : %i\n", value);
      exit(EXIT_FAILURE);
    }
	}

	for(i=0; i<nThreads; i++){
		value=pthread_create(&threadsC[i],NULL,&consumer,NULL);
    if(value){
      fprintf(stderr, "Error during the consumer threads launch. Error number : %i\n", value);
      exit(EXIT_FAILURE);
    }
	}
  value=pthread_create(&threadS,NULL,&sorter,NULL);
  if(value){
    fprintf(stderr, "Error during the sorter threads launch. Error number : %i\n", value);
    exit(EXIT_FAILURE);
  }



  // Join the treads
  for(i=0; i<nbrFilesIn; i++){                   // Not ready for files's type
    value=pthread_join(threadsP[i],NULL);
    if(value){
      fprintf(stderr, "Error during the producer threads reception. Error number : %i\n", value);
      exit(EXIT_FAILURE);
    }
  }
  for(i=0; i<nThreads; i++){
    value=pthread_join(threadsC[i],NULL);
    if(value){
      fprintf(stderr, "Error during the consumer threads reception. Error number : %i\n", value);
      exit(EXIT_FAILURE);
    }
  }
  value=pthread_join(threadS,NULL);
  if(value){
    fprintf(stderr, "Error during the sorter threads reception. Error number : %i\n", value);
    exit(EXIT_FAILURE);
  }



  // Semaphore destruction for the double producer consumer
  if(sem_destroy(&hashMutexEmpty)!=0){
    fprintf(stderr, "Error while initializing the semaphore hashMutexEmpty\n");
    exit(EXIT_FAILURE);
  }
  if(sem_destroy(&hashMutexFull)!=0){
    fprintf(stderr, "Error while initializing the semaphore hashMutexFull\n");
    exit(EXIT_FAILURE);
  }
  if(sem_destroy(&passwordMutexEmpty)!=0){
    fprintf(stderr, "Error while initializing the semaphore passwordMutexEmpty\n");
    exit(EXIT_FAILURE);
  };
  if(sem_destroy(&passwordMutexFull)!=0){
    fprintf(stderr, "Error while initializing the semaphore passwordMutexFull\n");
    exit(EXIT_FAILURE);
  }
  if(pthread_mutex_destroy(&lockHash)!=0){
    fprintf(stderr, "Error while initializing the mutex lockHash\n");
    exit(EXIT_FAILURE);
  }
  if(pthread_mutex_destroy(&lockPassword)!=0){
    fprintf(stderr, "Error while initializing the mutex unlockHash\n");
    exit(EXIT_FAILURE);
  }


  // Free the threads
  free(threadsP);
  free(threadsC);


  // Save the candidate passwords
  //save(fileOut);                    //don't work


  return EXIT_SUCCESS;

}
