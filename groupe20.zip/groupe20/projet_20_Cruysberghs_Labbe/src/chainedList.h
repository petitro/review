#ifndef _CHAINEDLIST_H
#define _CHAINEDLIST_H

#include <stdint.h>
#include <stdbool.h>


/**
* Structure candidate
*
* @next: pointer to the next candidate in the list, NULL if last candidate_t
* @password: password stored in the candidate
*/
typedef struct node{
  struct node *next;
  char *word;
}node_t;

 /**
 * Add @candidate at the "top" of the stack.
 *
 * @old : pointer to the top of the stack
 * @pswrd : the string to be placed in the element at the top of the stack
 *
 */
 node_t* push(char* pswrd, node_t* old);



 /**
 * Initialize the list with a "virtual" node (used for the functions but not print)
 *
 * @list : pointer to the top of the stack
 *
 */
 node_t* init(node_t* list);




 /**
 * Remove the top element of the stack.
 *
 * @top : pointer to the top of the stack
 *
 *
 */
 node_t* pop(node_t* top);

 /**
 * Return the content of the top element of the stack.
 *
 * @top : pointer to the top of the stack

 * pre : @result contains a null-terminated correct string of sufficient size
 * post : @result contains the string @name from the element at the top of the stack
 */
 char* get(node_t* top);

 /**
 * Return the first element of the content of the top element of the stack.
 *
 * @top : pointer to the top of the stack
 *
 * pre : @result contains a null-terminated correct string of sufficient size
 * post : @result contains the string @name from the element at the top of the stack
 */
 int get0(node_t* top);

 /**
 * Clear the stack (delete all).
 *
 * @top : pointer to the top of the stack
 *
 *
 */
 node_t* clear(node_t* top);

#endif
