#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <pthread.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <semaphore.h>
#include "reverse.h"
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include "tests.h"

#define LENGTH_OF_HASH 256



//=================================================================================================================================================================
//Data structures
//=================================================================================================================================================================



struct queue_node{
    struct queue_node *next;
    char *data;
} typedef t_queue_node;

//Queue structure
struct queue{
    t_queue_node *tail;
    int size;
} typedef t_queue;

//Hash array (length will be determined later)
uint8_t *hash_array;

//Reversed Hash array (length will be determined later)
char **reversed_hash_array;



//=================================================================================================================================================================
//Global Variables
//=================================================================================================================================================================



//Counters
int counter_fr = 0;
int counter_rh = 0;
int counter_rh_2 = 0; 
int counter_ws = 0;

//Number of reverse_hash and store_in_queue threads
int num_of_threads = 0;

//Number of files to determine the number of file_reader threads
int num_of_files;

//Variable that has its value determined by the selection criterium (1 for consonant, 0 for vowel)
int selection_criterium = 0;

//Variable that determines whether '-t' was used or not (1 of yes, 0 for no)
int thread_flag = 0;

//Variable that determines the index of first (and probably only) file declared
int file_index = 0;

//Variable that determines the maximum number of occurrences of either vowels or consonants
int max;

//MUTEX semaphore for hash_array
sem_t mutex;

//MUTEX semaphore for reverse_hash_array
sem_t mutex2;

//Producer/Consumer semaphores for hash_array
sem_t empty;
sem_t full;

//Producer/Consumer semaphores for reversed_hash_array
sem_t empty_2;
sem_t full_2;

//MUTEX for variable 'max'
sem_t mutex_max;

t_queue *queue;

t_queue_node *tail;

//Flag for the selection of the method to display the results (0 for standard output, 1 for the input of the results in a file)
int display_criterium = 0;

//File to insert the results (if requested)
char *file_results = NULL;

//Test flags
int file_reader_flag = 1;
int malloc_flag = 1;
int thread_creation_flag = 1;
int thread_joint_flag = 1;


//=================================================================================================================================================================
//Functions
//=================================================================================================================================================================



//Function that calculates size of file (Credits: https://stackoverflow.com/questions/8236/how-do-you-determine-the-size-of-a-file-in-c)
off_t fsize(const char *filename){
    struct stat st;

    if (stat(filename, &st) == 0){
        return st.st_size;
    }

    return -1;
}



//Function of the thread responsible for reading the binary files (Producer for 'hash_array')
void *file_reader(void *param){
    char *file_name = (char*) param;
    size_t size_of_file = fsize(file_name);
    int i;
    for (i = 0; i < size_of_file / LENGTH_OF_HASH; i++){
        uint8_t buffer = 0;
        sem_wait(&empty);
        sem_wait(&mutex);
        //Critical Section
        FILE *binary_file = fopen(file_name, "rb");
        if(!binary_file){
            file_reader_flag = 0;
        }
        int ret = fread(&buffer, LENGTH_OF_HASH, 1, binary_file);
        if(ret == -1){
            file_reader_flag = 0;
        }
        hash_array[counter_fr % num_of_threads] = buffer;
        counter_fr++;
        sem_post(&mutex);
        sem_post(&full);
    }
    return NULL;
}



//Function of the thread responsible for reversing the hashes in the hash_array and putting the results in the reverse_hash_array
//In a nutshell: Consumer for 'hash_array', Producer for 'reversed_hash_array'
void *hash_reverser(void *param){
    int *num_hashes = (int*)param;
    int i;
    for (i = 0; i < *num_hashes; i++){
        uint8_t hash;
        sem_wait(&full);
        sem_wait(&mutex);
        //Critical session for 'hash_array'
        hash = hash_array[counter_rh % num_of_threads];
        counter_rh++;
        sem_post(&mutex);
        sem_post(&empty);

        sem_wait(&empty_2);
        sem_wait(&mutex2);
        //Critical session for 'reversed_hash_array'
        reversehash(&hash, reversed_hash_array[counter_rh_2 % num_of_threads], LENGTH_OF_HASH, NULL);
        counter_rh_2++;
        sem_post(&mutex2);
        sem_post(&full_2);
    }
    return NULL;
}



//Error function
void error(int err, char *msg){
    fprintf(stderr, "%s returns %d, error message: %s\n", msg, err, strerror(errno));
}



//Function that calculates the number of occurrences for vowels or consonants
int calc_occurrences(char *word){
    int occurrences = 0;
    int i;
    for (i = 0; word[i] != '\0'; i++){
        if (selection_criterium){
            if (word[i] != 'a' && word[i] != 'b' && word[i] != 'c' && word[i] != 'd' && word[i] != 'e' && word[i] != 'y'){
                occurrences++;
            }
        }
        else{
            if (word[i] == 'a' || word[i] == 'b' || word[i] == 'c' || word[i] == 'd' || word[i] == 'e' || word[i] == 'y'){
                occurrences++;
            }
        }
    }
    return occurrences;
}



void create_queue(){
    queue->tail = tail;
    queue->tail->next = tail;
}



void enqueue(t_queue_node *new_tail){
    t_queue_node *next = queue->tail->next;
    queue->tail->next = new_tail;
    new_tail->next = next;
    queue->tail = new_tail;
    queue->size++;
}



void dequeue_all(){
    queue->tail->next = queue->tail;
    queue->tail->data = NULL;
    queue->size = 0;
}



//Function to print the words in the queue
void print_queue(void){
     t_queue_node *node = queue->tail;
    int i;
    for(i = 0; i < queue->size; i++){
        printf("%s\n", node->data);
        node = node->next;
    }
} 



//Function to insert the words in the queue in the file specified with the '-o' flag
void insert_words(char* filename){
    t_queue_node *node = queue->tail;
    int fd = open(filename, O_CREAT | O_RDWR);
    int i;
    for(i = 0; i < queue->size; i++){
        int w = write(fd, node->data, strlen(node->data));
        if(w == -1){
            perror("Error: ");
        }
        node = node->next;
    }
}



//Function for thread responsible for selecting the candidate words (Consumer for reversed_hash_array)
void *word_selector(void *param){
    int *num_of_hashes = (int*) param;
    int i;
    for(i = 0; i < *num_of_hashes; i++){
        sem_wait(&full_2);
        sem_wait(&mutex2);
        //Critical session
        char *word = reversed_hash_array[counter_ws%num_of_threads];
        counter_ws++;
        sem_post(&mutex2);
        sem_post(&empty_2);
        int num_occurrences = calc_occurrences(word);
        sem_wait(&mutex_max);
        if(num_occurrences > max){
            if(max > 0){
                dequeue_all();
            }
            max = num_occurrences;
        }
        if(num_occurrences == max){
            t_queue_node *node = malloc(sizeof(t_queue_node*));
            node->data = word;
            if(node == NULL){
                malloc_flag = 0;
            }
            node->data = word;
            enqueue(node);
            free(node);
        }
        sem_post(&mutex_max);
    }
    return NULL;
}



void file_reader_test(void){
    CU_ASSERT(file_reader_flag);
}



void malloc_test(void){
    CU_ASSERT(malloc_flag);
}


void thread_creation_test(void){
    CU_ASSERT(thread_creation_flag);
}


void thread_joint_test(void){
    CU_ASSERT(thread_joint_flag);
}



//=================================================================================================================================================================
//Main Function
//=================================================================================================================================================================



int main(int argc, char **argv){
    //Initialization of variables
    num_of_threads = 0;
    selection_criterium = 0;
    thread_flag = 0;
    file_index = 0;
    display_criterium = 0;
    file_results = NULL;

    //Initialization of CUnit suites
    initiate_registry();
    initialize_fr_test(&file_reader_test);
    initialize_malloc_test(&malloc_test);
    initialize_thread_c_test(&thread_creation_test);
    initialize_thread_j_test(&thread_joint_test);

    //getopd code
    int option;

    //Variable flag to determine if the flags in 'getopd' code where invoked
    int flag = 0;

    while ((option = getopt(argc, argv, "t:co:")) != -1){
        switch (option){
        case 't':
            //Set number of threads
            num_of_threads = atoi(optarg);
            //The flag is incremented by two here because the flag and its argument increment argc by 2
            flag += 2;
            thread_flag++;
            continue;
        case 'c':
            //Set selection criterium
            selection_criterium = 1;
            flag++;
            continue;

        case 'o':
            //Set display criterium
            display_criterium = 1;
            file_results = optarg;
            flag++;
            continue;
        default:
            break;
        }
    }

    //Code to check wheter '-t' flag was used ot not
    if (!thread_flag){
        num_of_threads = 1;
    }

    //If no flag was written (which implies that 'flag' was never incremented), then only the filenames were given
    if (!flag){
        num_of_files = argc - 1;
        file_index = 1;
    }
    else{
        num_of_files = argc - flag - 1;
        file_index = flag + 1;
    }

    create_queue();

    //Initialize hash_array mutex semaphore
    sem_init(&mutex, 0, 1);

    //Initialize hash_array producer/consumer semaphores
    sem_init(&empty, 0, num_of_threads);
    sem_init(&full, 0, 0);

    //Code to determine size of 'hash_array'
    hash_array = malloc(sizeof(uint8_t) * num_of_threads);

    //Code to execute file reader threads
    pthread_t file_reader_thread[num_of_files];
    int err1;
    int i;
    for (i = 0; i < num_of_files; i++){
        //File name
        char *filename = argv[file_index + i];

        err1 = pthread_create(&file_reader_thread[i], NULL, file_reader, filename);
        if (err1 != 0){
            thread_creation_flag = 0;
        }
    }

    int j;
    for (j = 0; j < num_of_files; j++){
        err1 = pthread_join(file_reader_thread[j], NULL);
        if (err1 != 0){
            thread_joint_flag = 0;
        }
    }

    //Initialize reversed_hash_array mutex semaphore
    sem_init(&mutex2, 0, 1);

    //Initialize reversed_hash_array producer/consumer consumer
    sem_init(&empty, 0, num_of_threads);
    sem_init(&full, 0, 0);

    //Code to determine size of 'reversed_hash_array'
    reversed_hash_array = malloc(sizeof(char *) * num_of_threads);

    //Code to determine the total number of hashes in all files
    int num_hashes = 0;
    int k;
    for (k = 0; k < num_of_files; k++){
        size_t file_size = fsize(argv[file_index + k]);
        num_hashes += (file_size / LENGTH_OF_HASH);
    }

    //Code to execute hash_inverser threads
    pthread_t hash_reverser_thread[num_of_threads];
    int err2;
    int l;
    for (l = 0; l < num_of_threads; l++){
        err2 = pthread_create(&hash_reverser_thread[l], NULL, hash_reverser, &num_hashes);
        if (err2 != 0){
            thread_creation_flag = 0;
        }
    }

    int m;
    for (m = 0; m < num_of_threads; m++){
        err2 = pthread_join(hash_reverser_thread[m], NULL);
        if (err2 != 0){
            thread_joint_flag = 0;
        }
    }

    //Initialize mutex for variable 'max'
    sem_init(&mutex_max, 0, 1);

    //Word selector thread
    pthread_t word_selector_thread[num_of_threads];
    int err3;
    int n;
    for(n = 0; n < num_of_threads; n++){
        err3 = pthread_create(&word_selector_thread[n], NULL, word_selector, &num_hashes);
        if(err3 != 0){
            thread_creation_flag = 0;
        }
    }

    int o;
    for(o = 0; o < num_of_threads; o++){
        err3 = pthread_join(word_selector_thread[o], NULL);
        if(err3 != 0){
            thread_joint_flag = 0;
        }
    }

    // Piece of code that either inserts the words in a file or prints the file
    if(display_criterium){
        insert_words(file_results);
    }else{
        print_queue();
    }
    finish_tests();

    return 0;
}