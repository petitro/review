#include <stdio.h>
#include <stdlib.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include "tests.h"

void initiate_registry(){
    CU_initialize_registry();
}

void initialize_fr_test(void (*f)(void)){
    CU_pSuite file_reader_suite = CU_add_suite("file_reader_test", 0, 0);
    CU_add_test(file_reader_suite, "file_reader_test", *f);
}

void initialize_malloc_test(void (*f)(void)){
    CU_pSuite malloc_suite = CU_add_suite("malloc_test", 0, 0);
    CU_add_test(malloc_suite, "malloc_test", *f);
}

void initialize_thread_c_test(void (*f)(void)){
    CU_pSuite malloc_suite = CU_add_suite("thread_creation_test", 0, 0);
    CU_add_test(malloc_suite, "thread_creation_test", *f);
}

void initialize_thread_j_test(void (*f)(void)){
    CU_pSuite malloc_suite = CU_add_suite("thread_creation_joint", 0, 0);
    CU_add_test(malloc_suite, "thread_creation_joint", *f);
}

void finish_tests(){
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();
}