#ifndef _TEST_H
#define _TEST_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>

void initiate_registry();

void initialize_fr_test(void (*f)(void));

void initialize_malloc_test(void (*f)(void));

void initialize_thread_c_test(void (*f)(void));

void initialize_thread_j_test(void (*f)(void));

void finish_tests();

void reset_flag();

#endif