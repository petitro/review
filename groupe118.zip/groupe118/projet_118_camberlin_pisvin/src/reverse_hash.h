#ifndef _REVERSE_HASH
#define _REVERSE_HASH_



void* reverse_hash();
#endif

