#ifndef _INSERT_
#define _INSERT_

int count_consonants(char* monString);

int count_vowels(char* monString);

int insert(node **head, char val[]);

int insertInList(char* mdp);

void* insert_mdp();

int freeLinkedList(node **head);

int printList(node** head);


#endif
