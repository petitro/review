#ifndef _LECTURE_FICHIER
#define _LECTURE_FICHIER


void *lectureFichier();
#endif
